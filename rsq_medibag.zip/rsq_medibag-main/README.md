# # # # # # # # # # # # # # # # # # # # # # # # # # #
#      ____    ____     ____  __   __ __   __       #
#     |  _ \  / ___|   / ___| \ \ / / \ \ / /       #
#     | |_) | \___ \  | |      \ V /   \ V /        #
#     |  _ <   ___) | | |___    | |     | |         #
#     |_| \_| |____/   \____|   |_|     |_|         #
#                                                   #
#                                                   #
#     Discord: https://rscyy.space/discord          #
#     Website: https://rscyy.space/                 #
#     Socials: https://rscyy.space/social           #
# # # # # # # # # # # # # # # # # # # # # # # # # # # 


Thank you for downloading my script <3 

Setup: 
      1. In client.lua file just add vehicle models in the allowedVehicles section
      2. Restart script and enjoy!

WARNING ! 
Do not copy anything from this script and use it as your self !
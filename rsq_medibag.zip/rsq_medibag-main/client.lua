local allowedVehicles = {
    `CHANGE_ME`, -- ALSO YOU CAN ADD MORE CARS !
}

local medibags = {}

local carryingBag = false
local bagEntity = nil
local currentVehicle = nil

local function isAllowedVehicle(vehicle)
    local model = GetEntityModel(vehicle)

    for _, v in pairs(allowedVehicles) do
        if model == v then
            return true
        end
    end

    return false
end

local function attachBag()
    AttachEntityToEntity(
        bagEntity,
        PlayerPedId(),
        GetPedBoneIndex(PlayerPedId(), 57005),
        0.4, 0.0, 0.0,
        0.0, 270.0, 60.0,
        true, true, false, true, 1, true
    )
end

local function removeBag()
    if DoesEntityExist(bagEntity) then
        DeleteEntity(bagEntity)
    end

    bagEntity = nil
end

local function createBag()
    lib.requestModel(`xm_prop_x17_bag_med_01a`)

    bagEntity = CreateObject(
        `xm_prop_x17_bag_med_01a`,
        0.0, 0.0, 0.0,
        true, true, true
    )

    attachBag()
end

CreateThread(function()
    exports.ox_target:addGlobalVehicle({
        {
            name = 'medibag_action',
            label = 'Take / Return Medibag',
            icon = 'fa-solid fa-kit-medical',
            distance = 2.0,
            bones = { 'boot' },

            canInteract = function(entity)
                return isAllowedVehicle(entity)
            end,

            onSelect = function(data)
                local vehicle = data.entity
                local netId = NetworkGetNetworkIdFromEntity(vehicle)

                -- TAKE BAG
                if not carryingBag and not medibags[netId] then
                    ExecuteCommand('me Taking medibag from car')

                    medibags[netId] = true
                    carryingBag = true
                    currentVehicle = netId

                    createBag()

                    lib.showTextUI('[E] Place medibag', {
                        position = 'right-center',
                        icon = 'fa-solid fa-kit-medical'
                    })

                elseif carryingBag and currentVehicle == netId then
                    ExecuteCommand('me Putting medibag into the car')

                    carryingBag = false
                    medibags[netId] = false
                    currentVehicle = nil

                    lib.hideTextUI()

                    removeBag()
                end
            end
        }
    })
end)

CreateThread(function()
    while true do
        local sleep = 1000

        if carryingBag then
            sleep = 0

            if IsControlJustPressed(0, 38) then 
                ExecuteCommand('me Placing medibag')

                carryingBag = false

                lib.hideTextUI()

                DetachEntity(bagEntity, true, true)

                local coords = GetEntityCoords(PlayerPedId())

                SetEntityCoords(
                    bagEntity,
                    coords.x,
                    coords.y,
                    coords.z - 1.0
                )

                PlaceObjectOnGroundProperly(bagEntity)

                exports.ox_target:addLocalEntity(bagEntity, {
                    {
                        name = 'pickup_medibag',
                        label = 'Take medibag',
                        icon = 'fa-solid fa-hand',

                        onSelect = function()
                            ExecuteCommand('me Taking medibag from ground')

                            carryingBag = true

                            attachBag()

                            lib.showTextUI('[E] Place medibag', {
                                position = 'right-center',
                                icon = 'fa-solid fa-kit-medical'
                            })
                        end
                    }
                })
            end
        end

        Wait(sleep)
    end
end)
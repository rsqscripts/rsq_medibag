fx_version 'cerulean'
game 'gta5'

author 'RSQ Scripts // rscyy'
version '0.1.2'

shared_script '@ox_lib/init.lua'

client_scripts {
    '@ox_target/client.lua',
    'client.lua'
}